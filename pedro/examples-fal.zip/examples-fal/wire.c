#include <stdio.h>
#include <stdlib.h>


int main() {
  int rows,cols,wires;
  
  int i,j,c;
  int *goal_row,*goal_col;
  int *col;
  
  printf("instances\n");
  scanf("%d\n",&rows);
  printf("  row 0..%d.\n",rows-1);
  scanf("%d\n",&cols);
  printf("  col 0..%d.\n",cols-1);
  scanf("%d\n",&wires);
  printf("  wire 0..%d.\n",wires-1);
  
  goal_row = (int *) malloc(wires*sizeof(int));
  goal_col = (int *) malloc(wires*sizeof(int));
  for (i=0;i<wires;i++) goal_row[i]=-1;

  printf("initially\n");  
  for (i=0;i<rows;i++) {
    for (j=0;j<cols;j++) {
      c=getchar();
      switch (c) {
        case '.':
	  break;
	case 'X':
	  printf("  not empty(%d,%d).\n",i,j);
	  break;
	default:
	  c-='0';
	  if (goal_row[c]==-1) {
	    printf("  wrow(%d)=%d. wcol(%d)=%d.\n",c,i,c,j);	  
	    goal_row[c]=-2;	  
	  }
	  else {
	    goal_row[c]=i;
	    goal_col[c]=j;
	  }
      }
    }
    getchar();
  }
  
  printf("goals\n");
  for (i=0;i<wires;i++) 
    printf("  wrow(%d)=%d. wcol(%d)=%d.\n",i,goal_row[i],i,goal_col[i]);
  free(goal_row);
  free(goal_col);
}
